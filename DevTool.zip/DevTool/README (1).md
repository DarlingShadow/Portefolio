Les programmes sont développé par Shadow Dev.
Ils demande les droits admin pour fonctionner ou non .
Il peut être signalé par antivirus 
Laisser activer pour eviter tout problème et essayer de laisser l'acces a ce que les programme ont besoin pour fonctionner 
